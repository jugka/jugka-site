package com.synyx.springtest.service;

import java.util.List;

import com.synyx.springtest.domain.Order;

/**
 * Interface for the order service.
 * 
 * @author Oliver Schlicht
 */
public interface OrderService {

    /**
     * Places an order.
     * 
     * @param order
     */
    public abstract void placeOrder(Order order);
    
    
    /**
     * Returns all orders.
     * 
     * @return
     */
    public List<Order> getOrders();
}