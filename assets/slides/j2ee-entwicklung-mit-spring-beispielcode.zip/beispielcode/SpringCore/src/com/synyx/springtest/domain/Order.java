package com.synyx.springtest.domain;

import java.io.Serializable;

/**
 * Domain class representing an order.
 * 
 * @author Oliver Schlicht
 */
public class Order implements Serializable {

    private static final long serialVersionUID = 8962107039000803273L;
    private Integer orderNumber;

    /**
     * Returns the order number.
     * 
     * @return
     */
    public Integer getOrderNumber() {
	return orderNumber;
    }

    /**
     * Sets the order number.
     * 
     * @param orderNumber
     */
    public void setOrderNumber(Integer orderNumber) {
	this.orderNumber = orderNumber;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {

	return "Order: " + orderNumber;
    }

}
