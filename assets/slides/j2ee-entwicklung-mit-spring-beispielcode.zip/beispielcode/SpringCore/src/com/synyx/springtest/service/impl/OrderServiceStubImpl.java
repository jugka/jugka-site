package com.synyx.springtest.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;

/**
 * Stub implementation of an order service, simply logging method calls.
 * 
 * @author Oliver Schlicht
 */
public class OrderServiceStubImpl implements OrderService {

    private static final Logger log = Logger.getLogger(OrderServiceStubImpl.class);

    private List<Order> orders;

    /**
     * Constructor of OrderServiceStubImpl.
     */
    public OrderServiceStubImpl() {

	this.orders = new ArrayList<Order>();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.service.OrderService#placeOrder(com.synyx.springtest.domain.Order)
     */
    public void placeOrder(Order order) {

	log.info(order);
	orders.add(order);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.service.OrderService#getOrders()
     */
    public List<Order> getOrders() {

	return this.orders;
    }
}