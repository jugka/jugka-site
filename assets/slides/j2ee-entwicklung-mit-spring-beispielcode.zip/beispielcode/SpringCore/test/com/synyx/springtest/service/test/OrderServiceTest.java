package com.synyx.springtest.service.test;

import junit.framework.TestCase;

import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;
import com.synyx.springtest.service.impl.OrderServiceStubImpl;

/**
 * Base test class to black box test an OrderService implementation. The
 * instance to test is retrieved from <code>getServiceTotest()</code>.
 * Overwrite this method in subclasses to run the test against other
 * implementations.
 * 
 * @author Oliver Schlicht
 * 
 */
public class OrderServiceTest extends TestCase {

    /**
     * Returns a service instance to test.
     * 
     * @return
     */
    protected OrderService getServiceToTest() {

	return new OrderServiceStubImpl();
    }

    /**
     * Tests, that the service stores placed orders correctly.
     */
    public final void testStoresOrdersCorrectly() {

	// Retrieve instance to test
	OrderService service = getServiceToTest();

	for (int i = 1; i < 100; i++) {

	    // Create order
	    Order order = new Order();
	    order.setOrderNumber(i);

	    // Use service
	    service.placeOrder(order);
	    
	    // Assert the service lists the given order
	    assertTrue(service.getOrders().contains(order));
	    
	    // Assert correct list size
	    assertEquals(i, service.getOrders().size());
	}
    }
}
