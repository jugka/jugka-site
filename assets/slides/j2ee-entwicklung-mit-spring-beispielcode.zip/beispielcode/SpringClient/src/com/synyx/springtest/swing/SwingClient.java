package com.synyx.springtest.swing;

import javax.swing.JFrame;


/**
 * Example Swing client to access the order service.
 * 
 * @author Oliver Schlicht
 */
public class SwingClient extends JFrame {

    private static final String FRAME_TITLE = "Order client";
    
    /**
     * Constructor of SwingClient. Simply wraps the given panel.
     * 
     * @param orderPanel
     */
    public SwingClient(OrderPanel orderPanel) {
	
	super(FRAME_TITLE);
	add(orderPanel);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	pack();
	setVisible(true);
    }
}