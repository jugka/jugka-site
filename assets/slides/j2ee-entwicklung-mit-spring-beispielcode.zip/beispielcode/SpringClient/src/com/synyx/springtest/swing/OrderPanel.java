package com.synyx.springtest.swing;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;

/**
 * Panel that hands orders to the order service.
 * 
 * @author Oliver Schlicht
 */
public class OrderPanel extends JPanel {
    
    // GUI elements
    private JTextField orderNumberField;
    private JButton submitOrderButton;
    
    // Service
    private OrderService orderService;
    
    /**
     * Constructor of OrderPanel.
     * 
     * @param orderService the service to hand the orders to
     */
    public OrderPanel(OrderService orderService) {
	
	this.orderService = orderService;
	
	initComponents();
	setPreferredSize(new Dimension(200,30));
    }
    
    
    /**
     * Initializes GUI components.
     */
    private void initComponents() {
	
	orderNumberField = new JTextField();
	orderNumberField.setPreferredSize(new Dimension(50, 20));
	orderNumberField.setHorizontalAlignment(JTextField.RIGHT);
	orderNumberField.setText("0");
	orderNumberField.selectAll();
	this.add(orderNumberField);
	
	submitOrderButton = new JButton("Submit order");
	submitOrderButton.setPreferredSize(new Dimension(120, 20));
	submitOrderButton.addActionListener(new ActionListener() {

	    /*
	     * (non-Javadoc)
	     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	     */
	    public void actionPerformed(ActionEvent e) {
		
		invokePlaceOrder();
	    }   
	});
	
	this.add(submitOrderButton);
    }
    
    
    /**
     * Hands the order to the order service.
     */
    private void invokePlaceOrder() {
	
	// Retrieve order number from text field
	Integer orderNumber = Integer.parseInt(orderNumberField.getText());
	
	// Create order
	Order order = new Order();
	order.setOrderNumber(orderNumber);
	
	// Place order
	orderService.placeOrder(order);
    }

}
