package com.synyx.springtest;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.synyx.springtest.bot.Bot;

/**
 * Launcher to start both the clients.
 * 
 * @author Oliver Schlicht
 */
public class Launcher {

    private static final String BOT_CONTEXT = "botContext.xml";
    private static final String SWING_CONTEXT = "swingContext.xml";
    
    /**
     * Main method.
     * 
     * @param args
     * @throws InterruptedException 
     */
    public static void main(String[] args) throws InterruptedException {

	// launchSwingApp();
	launchBot();
    }
    
    
    /**
     * Launches the bot.
     * 
     * @throws InterruptedException
     */
    private static void launchBot() throws InterruptedException {
	
	AbstractApplicationContext ctx = new ClassPathXmlApplicationContext(BOT_CONTEXT);
	ctx.registerShutdownHook();

	Bot client = (Bot) ctx.getBean("Bot");
	client.place1000Orders();
    }
    
    
    /**
     * Launches the swing application.
     */
    private static void launchSwingApp() {
	
	new ClassPathXmlApplicationContext(SWING_CONTEXT).registerShutdownHook();
    }

}
