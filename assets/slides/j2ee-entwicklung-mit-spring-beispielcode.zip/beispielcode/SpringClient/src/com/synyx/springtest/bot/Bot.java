package com.synyx.springtest.bot;

import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;

/**
 * Bot class to place orders in interval of 2 seconds.
 * 
 * @author Oliver Schlicht
 */
public class Bot {

    private OrderService orderService;
    
    /**
     * DI setter for the order service.
     * 
     * @param orderService
     */
    public void setOrderService(OrderService orderService) {
	this.orderService = orderService;
    }

    
    /**
     * Invoke placing 1000 orders.
     */
    public void place1000Orders() {

	for (int i = 0; i < 1000; i++) {

	    // Create new order
	    Order order = new Order();
	    order.setOrderNumber(i);

	    // Submit order
	    orderService.placeOrder(order);

	    // Hold on for 2 seconds
	    try {
		Thread.sleep(2000);
	    } catch (InterruptedException e) {
		return;
	    }
	}
    }
}
