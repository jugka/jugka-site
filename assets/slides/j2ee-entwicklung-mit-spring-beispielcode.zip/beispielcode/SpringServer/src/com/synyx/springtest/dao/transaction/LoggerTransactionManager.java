package com.synyx.springtest.dao.transaction;

import org.apache.log4j.Logger;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.SimpleTransactionStatus;

/**
 * Implementation of a transaction manager, simply logging transactional calls.
 * 
 * @author Oliver Schlicht
 */
public class LoggerTransactionManager implements PlatformTransactionManager {

    private static final Logger log = Logger
	    .getLogger(LoggerTransactionManager.class);

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.transaction.PlatformTransactionManager#commit(org.springframework.transaction.TransactionStatus)
     */
    public void commit(TransactionStatus arg0) throws TransactionException {

	log.info("Transaction committed!");
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.transaction.PlatformTransactionManager#getTransaction(org.springframework.transaction.TransactionDefinition)
     */
    public TransactionStatus getTransaction(TransactionDefinition arg0)
	    throws TransactionException {

	log.info("Transaction started!");

	return new SimpleTransactionStatus();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.transaction.PlatformTransactionManager#rollback(org.springframework.transaction.TransactionStatus)
     */
    public void rollback(TransactionStatus arg0) throws TransactionException {

	log.info("Transaction rolled back!");
    }

}
