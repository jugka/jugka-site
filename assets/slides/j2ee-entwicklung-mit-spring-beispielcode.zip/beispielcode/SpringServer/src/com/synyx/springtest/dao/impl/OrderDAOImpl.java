package com.synyx.springtest.dao.impl;

import java.util.ArrayList;
import java.util.List;

import com.synyx.springtest.dao.OrderDAO;
import com.synyx.springtest.domain.Order;

/**
 * "In memory" implementation of an order dao.
 * 
 * @author Oliver Schlicht
 */
public class OrderDAOImpl implements OrderDAO {

    private List<Order> orders;

    /**
     * Constructor of OrderDAOImpl.
     */
    public OrderDAOImpl() {

	this.orders = new ArrayList<Order>();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.dao.OrderDAO#findAllOrders()
     */
    public List<Order> findAllOrders() {

	return orders;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.dao.OrderDAO#saveOrder(com.synyx.springtest.domain.Order)
     */
    public void saveOrder(Order order) {

	this.orders.add(order);
    }
}