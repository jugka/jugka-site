/**
 * 
 */
package com.synyx.springtest.service.impl;

import java.util.List;

import org.apache.log4j.Logger;

import com.synyx.springtest.dao.OrderDAO;
import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;

/**
 * @author ollie
 * 
 */
public class OrderServiceImpl implements OrderService {

    private OrderDAO orderDAO;
    private static final Logger log = Logger.getLogger(OrderServiceImpl.class);

    /**
     * Constructor of OrderServiceImpl.
     * 
     * @param orderDAO
     */
    public OrderServiceImpl(OrderDAO orderDAO) {

	this.orderDAO = orderDAO;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.service.OrderService#placeOrder(com.synyx.springtest.domain.Order)
     */
    public void placeOrder(Order order) {

	log.info("Saving " + order);
	orderDAO.saveOrder(order);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.synyx.springtest.service.OrderService#getOrders()
     */
    public List<Order> getOrders() {

	return orderDAO.findAllOrders();
    }

}
