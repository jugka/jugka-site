/**
 * 
 */
package com.synyx.springtest.dao;

import java.util.List;

import com.synyx.springtest.domain.Order;

/**
 * Interface for an order data access object.
 * 
 * @author Oliver Schlicht
 */
public interface OrderDAO {

    /**
     * Returns all orders.
     * 
     * @return
     */
    public List<Order> findAllOrders();
    
    
    /**
     * Saves an order.
     * 
     * @param order
     */
    public void saveOrder(Order order);
}
