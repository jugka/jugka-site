package com.synyx.springtest;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Main class to launch the server.
 * 
 * @author Oliver Schlicht
 */
public class Server {

    /**
     * Main method.
     * 
     * @param args
     */
    public static void main(String[] args) {

	new ClassPathXmlApplicationContext("applicationContext.xml");
    }
}