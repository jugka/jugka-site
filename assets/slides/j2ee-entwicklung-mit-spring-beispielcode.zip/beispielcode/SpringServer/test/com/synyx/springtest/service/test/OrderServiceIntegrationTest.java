package com.synyx.springtest.service.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.synyx.springtest.service.OrderService;

/**
 * Integration test for order service configuration. Retrieves the order 
 * service from the service configuration file.
 * 
 * @author Oliver Schlicht
 */
public class OrderServiceIntegrationTest extends
	OrderServiceTest {

    private static final String BEAN_NAME = "OrderService";
    private static final String SERVICE_CONFIG = "services.xml";
    
    /*
     * (non-Javadoc)
     * @see com.synyx.springtest.service.test.OrderServiceTest#getServiceToTest()
     */
    @Override
    protected OrderService getServiceToTest() {
        
	// Launch context ans retrieve service
	ApplicationContext ctx = new ClassPathXmlApplicationContext(SERVICE_CONFIG);
	return (OrderService) ctx.getBean(BEAN_NAME);
    }
}