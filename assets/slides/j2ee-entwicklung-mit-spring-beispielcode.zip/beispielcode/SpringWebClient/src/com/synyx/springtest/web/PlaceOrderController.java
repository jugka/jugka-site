package com.synyx.springtest.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.synyx.springtest.domain.Order;
import com.synyx.springtest.service.OrderService;

/**
 * Controller to place orders. Retrieves an order object from the request and
 * hands it to the configured order service.
 * 
 * @author Oliver Schlicht
 */
public class PlaceOrderController extends SimpleFormController {

    private OrderService orderService;

    /**
     * DI setter for an order service.
     * 
     * @param orderService
     */
    public void setOrderService(OrderService orderService) {
	this.orderService = orderService;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.mvc.SimpleFormController#onSubmit(java.lang.Object,
     *      org.springframework.validation.BindException)
     */
    @Override
    protected ModelAndView onSubmit(HttpServletRequest request,
	    javax.servlet.http.HttpServletResponse response, Object command,
	    BindException errors) throws Exception {

	Order order = (Order) command;

	orderService.placeOrder(order);

	ModelAndView mav = new ModelAndView(getSuccessView());
	mav.addObject("message", "placeOrder.success");
	mav.addObject("order", order);
	mav.addAllObjects(referenceData(request));

	return mav;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.servlet.mvc.SimpleFormController#referenceData(javax.servlet.http.HttpServletRequest)
     */
    @Override
    protected Map referenceData(HttpServletRequest request) throws Exception {

	List<Order> orders = orderService.getOrders();

	Map<String, Object> map = new HashMap<String, Object>();
	map.put("orders", orders);

	return map;
    }
}
